public class BoundedArrayListMain {
 
 public static void main(String[] args) throws InterruptedException {
 
  final BoundedArrayList ba = new BoundedArrayList(5);
  System.out.println(ba.getArraylist());
  // Runnable runnable1 = null;
  
  
  Runnable runnable1 = new Runnable() {
 
   @Override
   
   public void run() {
       if (ba.emptyornot()) {
    try {
        
     ba.add("John");
     ba.add("Martin");
     ba.add("Adam");
     ba.add("Prince");
     ba.add("Tod");
    // System.out.println("Available Permits : "+ba.getSemaphore().availablePermits());
    // ba.add("Tony");
    // System.out.println("Final list: "+ba.getArraylist());
        
    } catch (InterruptedException ie) {
 
    }
    } //if
   }
  };
  
  
  Runnable runnable2 = new Runnable() {
      
   @Override
   public void run() {
    try {
     
     Thread.sleep(1000);
    // ba.remove222(1);
   // System.out.println("What is up y'all");
     ba.remove("John");
      ba.remove("Martin");
       ba.remove("Adam");
        ba.remove("Prince");
     ba.remove("Tod");
     System.out.println("Lol please work: "+ ba.getArraylist());
    } catch (InterruptedException e) {
     e.printStackTrace();
    }
   }
  };
  
 
   int a = 0;
     while (a == 0) {
  Thread t1 = new Thread(runnable1);
  Thread t2 = new Thread(runnable2);
  t1.start();
  System.out.println("Before removing elements: "+ ba.getArraylist());
  t2.start();
  System.out.println("Final list: "+ba.getArraylist());
 
 }
 
 }
}